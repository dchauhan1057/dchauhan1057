var showLog = true;

export const LogDisplay = (comment, value) => {
  showLog ? console.log(comment, value) : null;
};
