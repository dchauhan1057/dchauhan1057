export const fontFamily = {
  Roboto_Regular: 'Roboto-Regular',
  Roboto_Bold: 'Roboto-Bold',
  Roboto_Medium: 'Roboto-Medium',
};
